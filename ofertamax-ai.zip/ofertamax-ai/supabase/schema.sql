create table if not exists plataformas (
  id uuid primary key default gen_random_uuid(),
  nome text not null unique,
  url text not null
);
create table if not exists ofertas (
  id uuid primary key default gen_random_uuid(),
  titulo text not null,
  preco_antigo numeric(10,2) not null,
  preco_atual numeric(10,2) not null,
  desconto integer not null default 0,
  link text not null,
  imagem text,
  plataforma text not null,
  criado_em timestamptz not null default now()
);
create table if not exists cupons (
  id uuid primary key default gen_random_uuid(),
  codigo text not null,
  plataforma text not null,
  descricao text,
  validade date
);
create table if not exists agendamentos (
  id uuid primary key default gen_random_uuid(),
  titulo text not null,
  data_publicacao timestamptz not null,
  status text not null default 'agendado' check (status in ('agendado','publicado','cancelado'))
);

insert into plataformas (nome, url) values
  ('Shopee','https://shopee.com.br'), ('Amazon','https://amazon.com.br'),
  ('Mercado Livre','https://mercadolivre.com.br'), ('Magalu','https://magazineluiza.com.br'),
  ('Shein','https://br.shein.com'), ('Temu','https://temu.com')
on conflict (nome) do nothing;

-- MVP: acesso aberto com a chave anon. Antes de publicar, ative Supabase Auth
-- e troque estas políticas por "to authenticated" nas escritas.
alter table plataformas enable row level security;
alter table ofertas enable row level security;
alter table cupons enable row level security;
alter table agendamentos enable row level security;
create policy "all" on plataformas for all using (true) with check (true);
create policy "all" on ofertas for all using (true) with check (true);
create policy "all" on cupons for all using (true) with check (true);
create policy "all" on agendamentos for all using (true) with check (true);
