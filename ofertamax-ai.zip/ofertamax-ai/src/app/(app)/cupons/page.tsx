"use client";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { PLATAFORMAS } from "@/lib/utils";
import type { Cupom } from "@/lib/types";

const vazio = { codigo: "", plataforma: PLATAFORMAS[0], descricao: "", validade: "" };

export default function Cupons() {
  const [itens, setItens] = useState<Cupom[]>([]);
  const [f, setF] = useState(vazio);

  const carregar = useCallback(async () => {
    const { data } = await supabase.from("cupons").select("*").order("validade", { ascending: true });
    setItens((data ?? []) as Cupom[]);
  }, []);
  useEffect(() => { carregar(); }, [carregar]);

  async function salvar(e: React.FormEvent) {
    e.preventDefault();
    await supabase.from("cupons").insert({ ...f, validade: f.validade || null });
    setF(vazio); carregar();
  }
  async function apagar(id: string) { await supabase.from("cupons").delete().eq("id", id); carregar(); }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold md:text-3xl">Cupons</h1>
      <form onSubmit={salvar} className="card grid gap-3 md:grid-cols-5">
        <input required placeholder="Código" className="input" value={f.codigo} onChange={(e) => setF({ ...f, codigo: e.target.value })} />
        <select className="input" value={f.plataforma} onChange={(e) => setF({ ...f, plataforma: e.target.value })}>
          {PLATAFORMAS.map((p) => <option key={p}>{p}</option>)}
        </select>
        <input placeholder="Descrição" className="input" value={f.descricao} onChange={(e) => setF({ ...f, descricao: e.target.value })} />
        <input type="date" className="input" value={f.validade} onChange={(e) => setF({ ...f, validade: e.target.value })} />
        <button className="btn">Adicionar cupom</button>
      </form>
      {itens.length === 0 && <p className="card text-muted">Nenhum cupom cadastrado.</p>}
      <div className="grid gap-3 md:grid-cols-2">
        {itens.map((c) => {
          const vencido = c.validade && new Date(c.validade) < new Date(new Date().toDateString());
          return (
            <div key={c.id} className={`card space-y-2 ${vencido ? "opacity-50" : ""}`}>
              <div className="flex items-center justify-between">
                <span className="rounded-lg border border-dashed border-neon px-3 py-1 font-mono text-neon-light">{c.codigo}</span>
                <span className="text-sm text-muted">{c.plataforma}</span>
              </div>
              <p className="text-sm">{c.descricao}</p>
              <p className="text-xs text-muted">{c.validade ? `${vencido ? "Venceu" : "Vale até"} ${new Date(c.validade + "T00:00").toLocaleDateString("pt-BR")}` : "Sem validade"}</p>
              <div className="flex gap-2">
                <button className="btn-ghost" onClick={() => navigator.clipboard.writeText(c.codigo)}>Copiar</button>
                <button className="btn-ghost" onClick={() => apagar(c.id)}>Excluir</button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
