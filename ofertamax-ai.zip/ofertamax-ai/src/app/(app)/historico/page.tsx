"use client";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { PLATAFORMAS, brl } from "@/lib/utils";
import type { Oferta } from "@/lib/types";

export default function Historico() {
  const [itens, setItens] = useState<Oferta[]>([]);
  const [filtro, setFiltro] = useState("");

  const carregar = useCallback(async () => {
    let q = supabase.from("ofertas").select("*").order("criado_em", { ascending: false });
    if (filtro) q = q.eq("plataforma", filtro);
    const { data } = await q;
    setItens((data ?? []) as Oferta[]);
  }, [filtro]);
  useEffect(() => { carregar(); }, [carregar]);

  async function apagar(id: string) {
    await supabase.from("ofertas").delete().eq("id", id);
    carregar();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-2xl font-bold md:text-3xl">Histórico</h1>
        <select className="input w-auto" value={filtro} onChange={(e) => setFiltro(e.target.value)}>
          <option value="">Todas</option>
          {PLATAFORMAS.map((p) => <option key={p}>{p}</option>)}
        </select>
      </div>
      {itens.length === 0 && <p className="card text-muted">Nenhuma oferta encontrada.</p>}
      <ul className="space-y-3">
        {itens.map((o) => (
          <li key={o.id} className="card flex items-center gap-3">
            {o.imagem && <img src={o.imagem} alt="" className="h-14 w-14 rounded-lg object-cover" />}
            <div className="min-w-0 flex-1">
              <p className="truncate font-medium">{o.titulo}</p>
              <p className="text-sm text-muted">{o.plataforma} · {brl(o.preco_atual)} · -{o.desconto}% · {new Date(o.criado_em).toLocaleDateString("pt-BR")}</p>
            </div>
            <a href={o.link} target="_blank" rel="noopener noreferrer" className="btn-ghost">Abrir</a>
            <button onClick={() => apagar(o.id)} className="btn-ghost">Excluir</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
