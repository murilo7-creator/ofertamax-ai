import { supabase } from "@/lib/supabase";
import { OfertaCard } from "@/components/OfertaCard";
import type { Oferta } from "@/lib/types";

export const dynamic = "force-dynamic";

const total = async (t: string) =>
  (await supabase.from(t).select("*", { count: "exact", head: true })).count ?? 0;

export default async function Dashboard() {
  const [ofertas, cupons, agend, recentes] = await Promise.all([
    total("ofertas"), total("cupons"), total("agendamentos"),
    supabase.from("ofertas").select("*").order("criado_em", { ascending: false }).limit(4),
  ]);
  const stats = [
    { n: ofertas, l: "Ofertas" }, { n: cupons, l: "Cupons" }, { n: agend, l: "Agendamentos" },
  ];
  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold md:text-3xl">Painel</h1>
      <div className="grid grid-cols-3 gap-3">
        {stats.map((s) => (
          <div key={s.l} className="card">
            <p className="text-3xl font-bold text-neon-light md:text-4xl">{s.n}</p>
            <p className="text-sm text-muted">{s.l}</p>
          </div>
        ))}
      </div>
      <section>
        <h2 className="mb-3 text-lg font-semibold">Últimas ofertas</h2>
        {(recentes.data?.length ?? 0) === 0 ? (
          <p className="card text-muted">Você ainda não gerou nenhuma oferta.</p>
        ) : (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {(recentes.data as Oferta[]).map((o) => <OfertaCard key={o.id} o={o} />)}
          </div>
        )}
      </section>
    </div>
  );
}
