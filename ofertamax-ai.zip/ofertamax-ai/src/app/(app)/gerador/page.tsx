"use client";
import { useState } from "react";
import { supabase } from "@/lib/supabase";
import { PLATAFORMAS, brl, calcDesconto, num } from "@/lib/utils";

const vazio = { titulo: "", preco_antigo: "", preco_atual: "", link: "", imagem: "", plataforma: PLATAFORMAS[0] };

export default function Gerador() {
  const [f, setF] = useState(vazio);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const antigo = num(f.preco_antigo), atual = num(f.preco_atual);
  const desconto = calcDesconto(antigo, atual);
  const set = (k: keyof typeof vazio) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setF({ ...f, [k]: e.target.value });

  const texto = `🔥 ${f.titulo || "Título da oferta"}\n💸 De ${brl(antigo)} por ${brl(atual)} (-${desconto}%)\n🛒 ${f.plataforma}\n👉 ${f.link || "link"}`;

  async function salvar(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setMsg("");
    const { error } = await supabase.from("ofertas").insert({
      titulo: f.titulo, preco_antigo: antigo, preco_atual: atual, desconto,
      link: f.link, imagem: f.imagem || null, plataforma: f.plataforma,
    });
    setBusy(false);
    if (error) return setMsg(`Não foi possível salvar: ${error.message}`);
    setMsg("Oferta salva."); setF(vazio);
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold md:text-3xl">Gerar oferta</h1>
      <div className="grid gap-6 md:grid-cols-2">
        <form onSubmit={salvar} className="card space-y-4">
          <div><label className="label">Título</label><input required className="input" value={f.titulo} onChange={set("titulo")} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="label">Preço antigo</label><input required inputMode="decimal" className="input" value={f.preco_antigo} onChange={set("preco_antigo")} /></div>
            <div><label className="label">Preço atual</label><input required inputMode="decimal" className="input" value={f.preco_atual} onChange={set("preco_atual")} /></div>
          </div>
          <div><label className="label">Plataforma</label>
            <select className="input" value={f.plataforma} onChange={set("plataforma")}>{PLATAFORMAS.map((p) => <option key={p}>{p}</option>)}</select>
          </div>
          <div><label className="label">Link de afiliado</label><input required type="url" className="input" value={f.link} onChange={set("link")} /></div>
          <div><label className="label">URL da imagem</label><input type="url" className="input" value={f.imagem} onChange={set("imagem")} /></div>
          <button className="btn w-full" disabled={busy}>{busy ? "Salvando..." : "Salvar oferta"}</button>
          {msg && <p className="text-sm text-muted">{msg}</p>}
        </form>
        <div className="card h-fit space-y-4">
          <p className="text-sm text-muted">Desconto calculado</p>
          <p className="text-5xl font-bold text-off">{desconto}%</p>
          <pre className="whitespace-pre-wrap rounded-xl bg-bg p-3 text-sm">{texto}</pre>
          <button type="button" className="btn-ghost w-full" onClick={() => navigator.clipboard.writeText(texto)}>Copiar texto</button>
        </div>
      </div>
    </div>
  );
}
